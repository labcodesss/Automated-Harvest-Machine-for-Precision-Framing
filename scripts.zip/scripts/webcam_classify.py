import cv2
import joblib
import os
from scripts.preprocess import preprocess_image  # Uses histogram features

def run_webcam_classification():
    # Load model and label encoder
    model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'model', 'arecanut_model.pkl'))
    label_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'model', 'label_encoder.pkl'))

    if not os.path.exists(model_path) or not os.path.exists(label_path):
        print("Model or label encoder not found.")
        return

    model = joblib.load(model_path)
    label_encoder = joblib.load(label_path)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Cannot open webcam")
        return

    print("Press 'q' to quit")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Save frame temporarily for preprocessing
        temp_path = "temp_frame.jpg"
        cv2.imwrite(temp_path, frame)

        try:
            features = preprocess_image(temp_path).reshape(1, -1)
            pred_encoded = model.predict(features)[0]
            label = label_encoder.inverse_transform([pred_encoded])[0]

            cv2.putText(frame, f"Prediction: {label}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        except Exception as e:
            print(f"Error: {e}")

        cv2.imshow("Arecanut Classifier", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    if os.path.exists(temp_path):
        os.remove(temp_path)

if __name__ == "__main__":
    run_webcam_classification()
