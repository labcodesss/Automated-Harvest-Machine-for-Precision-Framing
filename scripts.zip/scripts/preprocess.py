import cv2
import numpy as np
import os

def preprocess_image(image_path, debug=False):
    try:
        if debug:
            print(f"\nProcessing: {image_path}")
            debug_dir = "debug_images"
            os.makedirs(debug_dir, exist_ok=True)

        # Read and validate image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError("Could not read image")

        if debug:
            cv2.imwrite(f"{debug_dir}/0_original.jpg", image)

        # Resize and convert to HSV
        image = cv2.resize(image, (224, 224))
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        
        if debug:
            cv2.imwrite(f"{debug_dir}/1_hsv.jpg", hsv)

        # Color masking
        lower = np.array([0, 20, 20])  # More lenient saturation/value
        upper = np.array([180, 255, 255])
        mask = cv2.inRange(hsv, lower, upper)
        
        if debug:
            cv2.imwrite(f"{debug_dir}/2_mask.jpg", mask)

        # Calculate coverage with adjusted threshold
        coverage = np.sum(mask > 0) / (224 * 224)
        if debug:
            print(f"Coverage: {coverage*100:.2f}%")

        if coverage < 0.1:  # Lowered threshold to 10%
            if debug:
                print("Low coverage - returning None")
            return None
        
        # Find largest contour
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            mask = np.zeros_like(mask)
            cv2.drawContours(mask, [largest_contour], -1, 255, -1)
            if debug:
                cv2.imwrite(f"{debug_dir}/3_contour.jpg", mask)

        # Feature extraction
        masked_hsv = cv2.bitwise_and(hsv, hsv, mask=mask)
        masked_pixels = masked_hsv[mask > 0]
        
        if len(masked_pixels) == 0:
            return None
            
        dominant_color = np.median(masked_pixels, axis=0)
        
        # Histograms
        hist_h = cv2.calcHist([hsv], [0], mask, [50], [0, 180])
        hist_s = cv2.calcHist([hsv], [1], mask, [60], [0, 256])
        hist_v = cv2.calcHist([hsv], [2], mask, [60], [0, 256])
        
        features = np.concatenate([
            cv2.normalize(hist_h, hist_h).flatten(),
            cv2.normalize(hist_s, hist_s).flatten(),
            cv2.normalize(hist_v, hist_v).flatten(),
            dominant_color
        ])
        
        if debug:
            print(f"Feature vector shape: {features.shape}")
            print(f"Dominant HSV: {dominant_color}")
            
        return features
        
    except Exception as e:
        print(f"Preprocessing error: {str(e)}")
        return None