import cv2

def capture_image(save_path='images/captured.jpg'):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Cannot open camera")
        return False

    print("Press 'c' to capture image.")
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            break

        cv2.imshow("Capture Image", frame)
        key = cv2.waitKey(1) & 0xFF

        if key == ord('c'):
            cv2.imwrite(save_path, frame)
            print(f"Image captured and saved to {save_path}")
            cap.release()
            cv2.destroyAllWindows()
            return True
        elif key == ord('q'):
            print("Capture cancelled")
            break

    cap.release()
    cv2.destroyAllWindows()
    return False
