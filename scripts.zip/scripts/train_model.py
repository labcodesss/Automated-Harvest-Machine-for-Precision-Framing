import os
import sys
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# Add project root to Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from scripts.preprocess import preprocess_image

def main():
    dataset_path = os.path.join(project_root, 'dataset')
    categories = ["ripe", "unripe", "rotten", "not_valid"]
    X = []
    y = []

    print("Loading and preprocessing dataset...")
    for label in categories:
        folder = os.path.join(dataset_path, label)
        if not os.path.exists(folder):
            print(f"Warning: {folder} does not exist - skipping")
            continue
            
        print(f"Processing {label} images...")
        for file in os.listdir(folder):
            image_path = os.path.join(folder, file)
            try:
                features = preprocess_image(image_path)
                if features is not None or label == "not_valid":
                    features = features if features is not None else np.zeros(173)
                    X.append(features)
                    y.append(label)
            except Exception as e:
                print(f"Skipping {file}: {str(e)}")

    if not X:
        raise ValueError("No training data found")

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Encode labels
    le = LabelEncoder()
    y_train_encoded = le.fit_transform(y_train)
    y_test_encoded = le.transform(y_test)

    print("\nTraining Random Forest model...")
    model = RandomForestClassifier(
        n_estimators=150,
        max_depth=10,
        min_samples_split=5,
        class_weight="balanced",
        random_state=42
    )
    model.fit(X_train, y_train_encoded)

    # Evaluate
    train_score = model.score(X_train, y_train_encoded)
    test_score = model.score(X_test, y_test_encoded)
    print(f"\nTraining Accuracy: {train_score:.2%}")
    print(f"Validation Accuracy: {test_score:.2%}")

    # Save model
    model_dir = os.path.join(project_root, 'model')
    os.makedirs(model_dir, exist_ok=True)
    
    model_path = os.path.join(model_dir, 'arecanut_model.pkl')
    label_path = os.path.join(model_dir, 'label_encoder.pkl')
    
    joblib.dump(model, model_path)
    joblib.dump(le, label_path)
    
    print(f"\nModel saved to:")
    print(f"- {model_path}")
    print(f"- {label_path}")

if __name__ == "__main__":
    main()