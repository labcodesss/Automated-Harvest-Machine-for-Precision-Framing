import os
import joblib
import numpy as np
from scripts.preprocess import preprocess_image

def predict_class(image_path, debug=False):
    try:
        if debug:
            print("\n" + "="*50)
            print(f"Predicting: {image_path}")

        # Load model with proper path handling
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(current_dir)
        
        model_path = os.path.join(project_root, 'model', 'arecanut_model.pkl')
        label_path = os.path.join(project_root, 'model', 'label_encoder.pkl')

        # Extract features with validity check
        features = preprocess_image(image_path, debug=debug)
        if features is None:
            return {
                "status": "invalid",
                "message": "Not an areca nut (low color coverage)",
                "confidence": 0
            }

        features = features.reshape(1, -1)
        
        if debug:
            print(f"Feature vector shape: {features.shape}")

        result = {
            "status": "valid",
            "model_prediction": None,
            "model_confidence": 0,
            "final_prediction": None,
            "message": ""
        }

        if os.path.exists(model_path) and os.path.exists(label_path):
            try:
                model = joblib.load(model_path)
                label_encoder = joblib.load(label_path)
                
                if hasattr(model, 'predict_proba'):
                    proba = model.predict_proba(features)[0]
                    pred = model.predict(features)[0]
                    label = label_encoder.inverse_transform([pred])[0]
                    confidence = max(proba) * 100
                    
                    result["model_prediction"] = label
                    result["model_confidence"] = confidence
                    
                    # Adjusted confidence threshold (changed from 60% to 40%)
                    if confidence >= 40:
                        result["final_prediction"] = label
                        result["message"] = f"{label.capitalize()} ({confidence:.1f}%)"
                    else:
                        result["final_prediction"] = "uncertain"
                        result["message"] = f"Low confidence prediction ({confidence:.1f}%)"
                    
                    return result
                
            except Exception as e:
                if debug:
                    print(f"Model prediction failed: {str(e)}")

        # Color-based fallback classification
        dominant_hue = features[0, -3]  # Dominant hue value
        
        if 5 <= dominant_hue <= 25:  # Ripe range
            confidence = 100 - abs(dominant_hue - 15)/10 * 50
            label = "ripe"
        elif 35 <= dominant_hue <= 85:  # Unripe range
            confidence = 100 - abs(dominant_hue - 60)/25 * 50
            label = "unripe"
        elif dominant_hue < 5 or dominant_hue > 85:  # Rotten range
            confidence = 100 - min(dominant_hue, 180-dominant_hue)/5 * 50
            label = "rotten"
        else:
            return {
                "status": "invalid",
                "message": "Color out of expected range",
                "confidence": 0
            }
            
        confidence = max(10, min(100, confidence))
        
        result["model_prediction"] = label
        result["model_confidence"] = confidence
        result["final_prediction"] = label if confidence >= 50 else "uncertain"
        result["message"] = f"{label.capitalize()} (~{confidence:.0f}%)" if confidence >= 50 else f"Uncertain prediction (~{confidence:.0f}%)"
        
        return result
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"System error: {str(e)}",
            "confidence": 0
        }